package edu.oswego.jeopardy;

import android.os.Parcel;
import android.os.Parcelable;

public class Question implements Parcelable {
    private String category;
    private int dollarValue;
    private String questionText;
    private String answerA;
    private String answerB;
    private String answerC;
    private String answerD;
    private String correctAnswer;

    @Override
    public int describeContents() {
        return hashCode();
    }

    //write object values to parcel for storage
    public void writeToParcel(Parcel dest, int flags){
        dest.writeString(category);
        dest.writeInt(dollarValue);
        dest.writeString(questionText);
        dest.writeString(answerA);
        dest.writeString(answerB);
        dest.writeString(answerC);
        dest.writeString(answerD);
        dest.writeString(correctAnswer);

    }
    public Question(Parcel parcel){
        this.category = parcel.readString();
        this.dollarValue = parcel.readInt();
        this.questionText = parcel.readString();
        this.answerA = parcel.readString();
        this.answerB = parcel.readString();
        this.answerC = parcel.readString();
        this.answerD = parcel.readString();
        this.correctAnswer = parcel.readString();
    }
    public static final Parcelable.Creator<Question> CREATOR = new Parcelable.Creator<Question>(){

        @Override
        public Question createFromParcel(Parcel parcel) {
            return new Question(parcel);
        }

        @Override
        public Question[] newArray(int size) {
            return new Question[0];
        }
    };
    public Question(){

    }

    public Question(String cat, int val, String text, String a, String b,
                    String c, String d, String answer){
        this.category = cat;
        this.dollarValue = val;
        this.questionText = text;
        this.answerA = a;
        this.answerB = b;
        this.answerC = c;
        this.answerD = d;
        this.correctAnswer = answer;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDollarValue(int inValue) {
        this.dollarValue = inValue;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public void setAnswerA(String answerA) {
        this.answerA = answerA;
    }

    public void setAnswerB(String answerB) {
        this.answerB = answerB;
    }

    public void setAnswerC(String answerC) {
        this.answerC = answerC;
    }

    public void setAnswerD(String answerD) {
        this.answerD = answerD;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public String getCategory() {
        return category;
    }

    public int getDollarValue() {
        return dollarValue;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getAnswerA() {
        return answerA;
    }

    public String getAnswerB() {
        return answerB;
    }

    public String getAnswerC() {
        return answerC;
    }

    public String getAnswerD() {
        return answerD;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
}