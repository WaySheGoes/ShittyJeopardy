package edu.oswego.jeopardy;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class QuestionActivity extends AppCompatActivity {
    Question question = new Question();
    Button A = findViewById(R.id.A);
    Button B = findViewById(R.id.B);
    Button C = findViewById(R.id.C);
    Button D = findViewById(R.id.D);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);
        question = GetQuestion();
        bindQuestion();
    }

    public Question GetQuestion(){
        Intent intent = getIntent();
        Question q = intent.getParcelableExtra("questionInGame");
        return q;
    }
    public void DoStuff(View view){
        Log.d("DoStuff", "DoStuff: "+view.getTag());
        Log.d("DoStuff", "DoStuff: "+question.getCorrectAnswer());
        if(question.getCorrectAnswer().toLowerCase().compareTo(view.getTag().toString().toLowerCase())==1){
            view.setBackgroundColor(Color.GREEN);
        }else{
            view.setBackgroundColor(Color.RED);
            switch(question.getCorrectAnswer().toLowerCase()){
                case "a": A.setBackgroundColor(Color.GREEN);
                    break;
                case "b": B.setBackgroundColor(Color.GREEN);
                    break;
                case "c": C.setBackgroundColor(Color.GREEN);
                    break;
                case "d": D.setBackgroundColor(Color.GREEN);
                    break;
            }
        }


        finish();
    }
    private void bindQuestion(){
        Log.d("a", "bindQuestion: here");
        TextView question1 = findViewById(R.id.question1);
        A.setTag("A");
        B.setTag("B");
        C.setTag("C");
        D.setTag("D");
        Log.d("a", "bindQuestion: here2");
        question1.setText(question.getQuestionText());
        A.setText(question.getAnswerA());
        B.setText(question.getAnswerB());
        C.setText(question.getAnswerC());
        D.setText(question.getAnswerD());
        Log.d("a", "bindQuestion: here3");
    }
}
