package edu.oswego.jeopardy;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Question> questionlist = new ArrayList<>();
    private ArrayList<String> categories = new ArrayList<>();
    private final String XMLURL = "http://cs.oswego.edu/~awalts2/questions.xml";

    private ArrayList<Question> questionsIngame = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LoadData();

    }
    public void LoadData(){
        new Thread() {
            @Override
            public void run() {
                QuestionParser questionparser = new QuestionParser(XMLURL);
                questionlist =questionparser.startParsing();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        SetInit();
                    }
                });
            }

        }.start();
    }

    public void SetQuestions(ArrayList<String> categories){
        int j =0;
        for(int i =0; i<30;i++) {
            if (j<5 && questionlist.get(i).getCategory() == categories.get(j)) {
                questionsIngame.add(questionlist.get(i));
                j++;
            }
        }
    }

    public ArrayList<String> GetCategories(){
        Random r = new Random();
        ArrayList<String> categories = new ArrayList<>();
        int size = questionlist.size()-1;
        boolean used = false;

        while(categories.size() != 5){
            String category = questionlist.get(r.nextInt(size)).getCategory();
            for(String s : categories){
                if(s == category){
                    used = true;
                }
            }
            if(used == false){
                categories.add(category);
            }
            used = false;
        }
        return categories;
    }

     public void SetInit(){
         categories = GetCategories();
         setContentView(R.layout.activity_main);
         TextView tv1 = (TextView)findViewById(R.id.tv1);
          tv1.setText(categories.get(0));
         TextView tv2 = (TextView)findViewById(R.id.tv2);
         tv2.setText(categories.get(1));
         TextView tv3 = (TextView)findViewById(R.id.tv3);
         tv3.setText(categories.get(2));
         TextView tv4 = (TextView)findViewById(R.id.tv4);
         tv4.setText(categories.get(3));
         TextView tv5 = (TextView)findViewById(R.id.tv5);
         tv5.setText(categories.get(4));
    }

    public Question GetQuestionIndex(View view){
        Button b1 = findViewById(R.id.button1);
        b1.setTag(1);
        Button b2 = findViewById(R.id.button2);
        b2.setTag(2);
        Button b3 = findViewById(R.id.button3);
        b3.setTag(3);
        Button b4 = findViewById(R.id.button4);
        b4.setTag(4);
        Button b5 = findViewById(R.id.button5);
        b5.setTag(5);
        Question q = new Question();
        if(questionsIngame.get(0) == null){
            Log.d("a", "GetQuestionIndex: empty");
            SetQuestions(categories);
        }
        switch(view.getTag().toString()){
            case "1":
                q = questionsIngame.get(0);
                break;
            case "2":
                q = questionsIngame.get(1);
                break;
            case "3":
                q = questionsIngame.get(2);
                break;
            case "4":
                q = questionsIngame.get(3);
                break;
            case "5":
                q = questionsIngame.get(4);
                break;
        }
        return q;
    }

    public void goToQuestion(View view){
        SetQuestions(categories);
        Question q =GetQuestionIndex(view);
        Intent intent = new Intent(this, QuestionActivity.class);
        view.getContentDescription();
        intent.putExtra("questionInGame",q);
        startActivity(intent);
        TextView t =(TextView)view;
        t.setText("");
        t.setOnClickListener(null);
        Toast.makeText(this, "", Toast.LENGTH_LONG).show();
    }
}
